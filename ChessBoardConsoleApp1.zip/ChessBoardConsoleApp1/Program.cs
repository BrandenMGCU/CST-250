﻿using ChessBoardModel1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessBoardConsoleApp1
{
    public class Program
    {
        // Create a new instance of the board
        static Board myBoard = new Board(8);
        static void Main(string[] args) // Because this is static, the Board myBoard must also be static, there is only one copy, one board allowed. 
        {
            // This will be the interface for the user.

            // We want to show a new game empty chess board to the user.
            printBoard(myBoard);

            // Ask the user for the X and Y coordinates of the board.
            Cell currentCell = setCurrentCell();
            currentCell.CurrentlyOccupied = true;

            // Calculate all the legal moves for that piece
            myBoard.MarkNextLegalMoves(currentCell,"Knight");

            // We will then show the chess board and will use X to show an occupied square. We'll show a + for a legal mod and . for an empty cell.
            printBoard(myBoard);


            // We will then wait for an additional key press before quiting the program.
            Console.ReadLine(); // This is here for the end of the game so it will not disappear.
        }

        private static Cell setCurrentCell()
        {
                // This will allow us to return the value of cell

                // get x and y coordinates from the user. Then return a cell location.
                Console.WriteLine();
                Console.WriteLine("Enter the current row number");
                int currentRow = int.Parse(Console.ReadLine()); // will convert it to an int

                Console.WriteLine("Enter the current column number");
                int currentColumn = int.Parse(Console.ReadLine());

                Console.WriteLine("What chess piece would you like to place on the board?" + " King, Queen, Knight, Bishop, or Rook?");
                string chessPiece = Convert.ToString(Console.ReadLine());

                myBoard.theGrid[currentRow, currentColumn].CurrentlyOccupied = true;
                return myBoard.theGrid[currentRow, currentColumn];  // This will return the current row and column from the board.
   
        }

        private static void printBoard(Board myBoard)
        {
            // This will print the chess board to the console. We will use X for the piece location and + for legal move and . for an empty square.

            // This will be the nested for loop
            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int b = 0; b < myBoard.Size; b++)
                {
                    Console.Write("+--");
                }
                Console.Write("+");
                Console.WriteLine();
                Console.Write("|");

                for (int j = 0; j < myBoard.Size; j++)
                {

                    Cell c = myBoard.theGrid[i, j];

                    if (c.CurrentlyOccupied == true)
                    {
                        Console.Write("X");
                    }
                    else if (c.LegalNextMove == true)
                    {
                        Console.Write("+");
                    }
                    else
                    {
                        Console.Write(" ");

                    }
                    Console.Write(" |");
                }

                Console.WriteLine();
            }

            for (int d = 0; d < myBoard.Size; d++)
            {
                Console.Write("+--");
            }
            Console.Write("+");
            Console.WriteLine();

            Console.WriteLine("===============================");
        }
    }
    }
